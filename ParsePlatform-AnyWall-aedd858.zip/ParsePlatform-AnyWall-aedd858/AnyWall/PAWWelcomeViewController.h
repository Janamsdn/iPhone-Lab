//
//  PAWViewController.h
//  AnyWall
//
//  Created by Christopher Bowns on 1/30/12.
//  Copyright (c) 2012 Parse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PAWWelcomeViewController : UIViewController

- (IBAction)loginButtonSelected:(id)sender;
- (IBAction)createButtonSelected:(id)sender;
- (IBAction)gotoParse:(id)sender;

@end
